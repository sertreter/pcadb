CREATE VIEW last_product AS
  SELECT
    `mydb_diplom`.`product`.`id_product`  AS `id_product`,
    `mydb_diplom`.`product`.`id_category` AS `id_category`,
    `mydb_diplom`.`product`.`name`        AS `name`,
    `mydb_diplom`.`product`.`description` AS `description`,
    `mydb_diplom`.`product`.`price`       AS `price`,
    `mydb_diplom`.`product`.`img_main`    AS `img_main`,
    `avg_rate`.`avg_rate`                 AS `avg_rate`
  FROM (`mydb_diplom`.`product`
    LEFT JOIN `mydb_diplom`.`avg_rate` ON ((`mydb_diplom`.`product`.`id_product` = `avg_rate`.`id_product`)))
  ORDER BY `mydb_diplom`.`product`.`date` DESC;
