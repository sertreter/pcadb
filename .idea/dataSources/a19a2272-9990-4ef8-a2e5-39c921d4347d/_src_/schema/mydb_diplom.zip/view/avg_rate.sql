CREATE VIEW avg_rate AS
  SELECT
    `mydb_diplom`.`reviews`.`id_product`  AS `id_product`,
    avg(`mydb_diplom`.`reviews`.`rating`) AS `avg_rate`
  FROM `mydb_diplom`.`reviews`
  GROUP BY `mydb_diplom`.`reviews`.`id_product`;
