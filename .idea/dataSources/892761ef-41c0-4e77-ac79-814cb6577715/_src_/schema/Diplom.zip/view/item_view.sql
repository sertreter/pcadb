CREATE VIEW item_view AS
  SELECT DISTINCT
    `diplom`.`characteristik`.`name` AS `name`,
    `diplom`.`items`.`id`            AS `id`
  FROM `diplom`.`items`
    JOIN `diplom`.`characteristik`
    JOIN `diplom`.`category`
    JOIN `diplom`.`property`
  WHERE ((`diplom`.`items`.`id_category` = `diplom`.`category`.`id`) AND
         (`diplom`.`characteristik`.`id_category` = `diplom`.`category`.`id`));
