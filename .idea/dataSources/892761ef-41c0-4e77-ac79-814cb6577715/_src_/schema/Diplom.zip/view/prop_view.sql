CREATE VIEW prop_view AS
  SELECT DISTINCT
    `diplom`.`property`.`name` AS `name`,
    `diplom`.`items`.`name`    AS `item`,
    `diplom`.`items`.`id`      AS `id`
  FROM `diplom`.`items`
    JOIN `diplom`.`item_prop`
    JOIN `diplom`.`property`
    JOIN `diplom`.`char_prop`
  WHERE ((`diplom`.`items`.`id` = `diplom`.`item_prop`.`id_item`) AND
         (`diplom`.`property`.`id` = `diplom`.`item_prop`.`id_prop`));
